#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int *array_create(int size);
int is_possible(int *arr_a, int size);

#endif
